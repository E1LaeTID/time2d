#pragma once
/*
  time2d_w2.h � W2 (Vent & Bois) � STRUCTURE UNIQUEMENT
  ------------------------------------------------------
  VENT :
    - subdivision_level (>=1)
    - offset_step (r�el, n�gatif/positif/0)
    - Si subdivision_level == 1 ET offset_step == 0 => �quivalent I2 (aucune sp�cialisation).

  BOIS :
    - Ce header NE d�cide pas de l��tat des empreintes.
      Il pr�pare un ensemble de �slots� (au plus subdivisions-1), chacun avec un offset.
      L�activation / disparition / maintien est g�r�e UNIQUEMENT dans time2d_macros.h
      via 4 variables macro :
        * PROCESS_EXISTENCE_TIME        (VENT � nb de rebonds "possibles")
        * PROCESS_SUPPORT_TIME          (VENT � contr�le d�effacement des empreintes)
        * ENVIRONNMENT_RECOVER_TIME     (BOIS � tag/identifiant du container de r�f�rence)
        * ENVIRONNMENT_CORPSE_TIME      (BOIS � co�t/mouvement pour maintenir des empreintes)
*/

#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include "time2d_i2.h" // I2Plan / I2Params

namespace t2d {

    // -------------------------
    // Param�trage W2 (VENT pur)
    // -------------------------
    struct W2Params {
        int    subdivision_level{ 1 }; // >= 1
        double offset_step{ 0.0 };     // peut �tre n�gatif, nul ou positif
    };

    // -------------------------
    // Sorties W2 (STRUCTURE)
    // -------------------------
    struct W2Slot {
        int    index{ 0 };      // 1..capacity pour les empreintes ; 0 r�serv� au conteneur
        int    subdivision{ 1 }; // subdivision locale (par d�faut = subdivision_level ou subdivision_level-1)
        double offset{ 0.0 };   // d�calage cumul� = index * offset_step
    };

    struct W2Plan {
        // Conteneur de r�f�rence (VENT)
        int    subdivision_level{ 1 };
        double offset_step{ 0.0 };

        // Capacit� de rebonds/empreintes disponible structurellement :
        // au plus (subdivision_level - 1)
        int    rebounds_capacity{ 0 };

        // Slot 0 = �container� (offset=0), puis 1..rebounds_capacity = emplacements possibles
        std::vector<W2Slot> slots;
    };

    // -------------------------
    // G�n�ration structurelle W2
    // -------------------------
    inline W2Plan generate_w2_structure(const I2Plan& i2, const W2Params& P) {
        (void)i2; // i2 peut servir d��chelle/annotation ult�rieure ; ici structure pure

        W2Plan out;
        out.subdivision_level = std::max(1, P.subdivision_level);
        out.offset_step = P.offset_step;
        out.rebounds_capacity = std::max(0, out.subdivision_level - 1);

        out.slots.reserve(out.rebounds_capacity + 1);

        // Slot 0 : container de r�f�rence
        {
            W2Slot s;
            s.index = 0;
            s.subdivision = out.subdivision_level; // subdivision du container
            s.offset = 0.0;
            out.slots.push_back(s);
        }

        // Slots 1..capacity : empreintes POTENTIELLES (BOIS)
        for (int k = 1; k <= out.rebounds_capacity; ++k) {
            W2Slot s;
            s.index = k;
            s.subdivision = std::max(1, out.subdivision_level - 1);
            s.offset = k * out.offset_step;
            out.slots.push_back(s);
        }

        return out;
    }

} // namespace t2d
